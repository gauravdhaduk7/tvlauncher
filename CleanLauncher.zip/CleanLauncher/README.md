# Clean Launcher for Mi TV

A tiny, ad-free home screen for Android TV: 5 big app tiles, a clock and a Settings button.
No internet permission, no ads, no recommendations.

## Using it
- **OK** on a tile opens the app.
- **Hold OK** (or press **Menu**) on a tile to change which app it shows. Pick "Remove from this tile" to clear it.
- An empty tile shows "+ Add app". Press OK on it to choose an app.
- The **Settings** button (top right) opens the TV settings, so you can always get back to them.

## 1. Build the APK (on a PC)
1. Install **Android Studio** (free) from developer.android.com/studio.
2. Choose **Open** and select the `CleanLauncher` folder. Wait for the Gradle sync to finish (first time needs internet).
3. Menu: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. When it finishes, click **locate**. The file is `app/build/outputs/apk/debug/app-debug.apk`.

## 2. Install on the TV
1. Copy `app-debug.apk` to a USB drive and plug it into the TV.
2. Open **File Manager+** on the TV, open the USB drive and select the APK.
3. If asked, allow "Install unknown apps" for File Manager+, then install.
4. Open **Clean Launcher** once from the Apps list to check it works.

## 3. Make it the home screen (one-time ADB step)
Android TV 10 does not let you pick a home app, so disable the stock one.

1. TV: **Settings > Device Preferences > About**, press OK on **Build** 7 times.
2. TV: **Settings > Device Preferences > Developer options**, turn on **USB debugging** (and **ADB over network** if shown).
3. On a PC on the same Wi-Fi: `adb connect <TV-IP>` (IP is under Settings > Network).
4. Find the current home app (do this BEFORE disabling anything):
   `adb shell cmd package resolve-activity -a android.intent.action.MAIN -c android.intent.category.HOME`
   Look for `packageName=`. It will usually be `com.google.android.tvlauncher` or something starting with `com.mitv`.
5. Disable the stock one (use the name from step 4):
   `adb shell pm disable-user --user 0 com.google.android.tvlauncher`
6. Press **Home** on the remote. Clean Launcher should open.

## Undo
`adb shell pm enable com.google.android.tvlauncher` (use the same package name) brings the old home screen back.
You can also just uninstall Clean Launcher.

## Changing the number of tiles or the default apps
Open `app/src/main/java/com/cleanlauncher/tv/MainActivity.kt`.
Change `slotCount` and the `defaultCandidates` list at the top, then rebuild.
