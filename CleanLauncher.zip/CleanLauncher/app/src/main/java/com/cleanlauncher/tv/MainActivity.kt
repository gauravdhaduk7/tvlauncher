package com.cleanlauncher.tv

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast

/**
 * A tiny, ad-free TV home screen.
 *  - 5 big tiles in one row
 *  - Press OK on a tile to open the app
 *  - Hold OK (or press MENU) on a tile to change which app it shows
 *  - No internet permission, no tracking, no recommendations
 */
class MainActivity : Activity() {

    private val slotCount = 5

    // First installed package in each list is used until you pick your own app.
    private val defaultCandidates: List<List<String>> = listOf(
        listOf("com.google.android.youtube.tv"),
        listOf("in.startv.hotstar", "in.startv.hotstar.dplus", "com.jio.jiohotstar"),
        listOf("com.netflix.ninja"),
        listOf("com.amazon.amazonvideo.livingroom"),
        listOf() // left empty so you can choose
    )

    private lateinit var prefs: SharedPreferences
    private lateinit var row: LinearLayout

    private data class AppEntry(val label: String, val pkg: String, val icon: Drawable?)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("slots", MODE_PRIVATE)
        window.setBackgroundDrawable(
            GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xFF0B1020.toInt(), 0xFF1B2440.toInt())
            )
        )
        setContentView(buildUi())
        refresh(0)
    }

    override fun onResume() {
        super.onResume()
        val focused = row.indexOfChild(currentFocus).coerceAtLeast(0)
        refresh(focused)
    }

    // The Home screen should never "go back" to anything.
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // intentionally empty
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_MENU) {
            val index = row.indexOfChild(currentFocus)
            if (index >= 0) {
                pickApp(index)
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    // ---------------------------------------------------------------- UI

    private fun dp(v: Int): Int =
        TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics
        ).toInt()

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(56), dp(36), dp(56), dp(36))
        }

        // Top bar: clock on the left, Settings on the right
        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val clock = TextClock(this).apply {
            format12Hour = "hh:mm a"
            format24Hour = "HH:mm"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 34f)
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        }
        topBar.addView(clock, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        val settingsBtn = TextView(this).apply {
            text = "Settings"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(12), dp(24), dp(12))
            isFocusable = true
            isClickable = true
            background = pillBg(false)
            setOnFocusChangeListener { v, has -> v.background = pillBg(has) }
            setOnClickListener {
                try {
                    startActivity(Intent(Settings.ACTION_SETTINGS))
                } catch (e: ActivityNotFoundException) {
                    toast("Settings not available")
                }
            }
        }
        topBar.addView(settingsBtn)
        root.addView(topBar, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // Middle: tile row, vertically centred
        row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            clipChildren = false
            clipToPadding = false
        }
        root.addView(row, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // Bottom hint
        val hint = TextView(this).apply {
            text = "Hold OK on a tile to change the app"
            setTextColor(0x99FFFFFF.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            gravity = Gravity.CENTER
        }
        root.addView(hint, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        root.clipChildren = false
        return root
    }

    private fun cardBg(focused: Boolean): GradientDrawable = GradientDrawable().apply {
        cornerRadius = dp(18).toFloat()
        setColor(if (focused) 0xFF3A4A7A.toInt() else 0xFF242F52.toInt())
        if (focused) setStroke(dp(3), Color.WHITE)
    }

    private fun pillBg(focused: Boolean): GradientDrawable = GradientDrawable().apply {
        cornerRadius = dp(24).toFloat()
        setColor(if (focused) 0xFF3A4A7A.toInt() else 0x33FFFFFF)
        if (focused) setStroke(dp(2), Color.WHITE)
    }

    private fun refresh(focusIndex: Int) {
        row.removeAllViews()
        for (i in 0 until slotCount) row.addView(makeTile(i))
        row.getChildAt(focusIndex.coerceIn(0, slotCount - 1))?.requestFocus()
    }

    private fun makeTile(index: Int): View {
        val pkg = slotPackage(index)
        val launchIntent = if (pkg.isNotEmpty()) launchIntentFor(pkg) else null

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            isFocusable = true
            isClickable = true
            background = cardBg(false)
            setPadding(dp(12), dp(12), dp(12), dp(12))
            layoutParams = LinearLayout.LayoutParams(dp(190), dp(220)).apply {
                marginStart = dp(12)
                marginEnd = dp(12)
            }
        }

        if (launchIntent != null) {
            val icon = ImageView(this).apply {
                setImageDrawable(runCatching { packageManager.getApplicationIcon(pkg) }.getOrNull())
                scaleType = ImageView.ScaleType.FIT_CENTER
            }
            card.addView(icon, LinearLayout.LayoutParams(dp(110), dp(110)))
            val name = TextView(this).apply {
                text = runCatching {
                    packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0))
                }.getOrDefault(pkg)
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
                gravity = Gravity.CENTER
                maxLines = 2
                setPadding(0, dp(12), 0, 0)
            }
            card.addView(name)
        } else {
            val plus = TextView(this).apply {
                text = "+"
                setTextColor(0xCCFFFFFF.toInt())
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 64f)
                gravity = Gravity.CENTER
            }
            card.addView(plus)
            val add = TextView(this).apply {
                text = "Add app"
                setTextColor(0xCCFFFFFF.toInt())
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
                gravity = Gravity.CENTER
            }
            card.addView(add)
        }

        card.setOnFocusChangeListener { v, has ->
            v.background = cardBg(has)
            val scale = if (has) 1.12f else 1f
            v.animate().scaleX(scale).scaleY(scale).setDuration(120).start()
            if (has) v.elevation = dp(8).toFloat() else v.elevation = 0f
        }
        card.setOnClickListener {
            if (launchIntent != null) {
                try {
                    startActivity(launchIntent)
                } catch (e: Exception) {
                    toast("Could not open this app")
                }
            } else {
                pickApp(index)
            }
        }
        card.setOnLongClickListener {
            pickApp(index)
            true
        }
        return card
    }

    // ---------------------------------------------------------------- data

    private fun slotPackage(index: Int): String {
        val key = "slot_$index"
        if (prefs.contains(key)) return prefs.getString(key, "") ?: ""
        val candidates = defaultCandidates.getOrNull(index).orEmpty()
        return candidates.firstOrNull { launchIntentFor(it) != null } ?: ""
    }

    private fun launchIntentFor(pkg: String): Intent? =
        packageManager.getLeanbackLaunchIntentForPackage(pkg)
            ?: packageManager.getLaunchIntentForPackage(pkg)

    private fun installedApps(): List<AppEntry> {
        val pm = packageManager
        val tv = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
        val phone = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return (pm.queryIntentActivities(tv, 0) + pm.queryIntentActivities(phone, 0))
            .map { it.activityInfo.packageName to it }
            .distinctBy { it.first }
            .filter { it.first != packageName }
            .map { (pkg, info) ->
                AppEntry(info.loadLabel(pm).toString(), pkg, runCatching { info.loadIcon(pm) }.getOrNull())
            }
            .sortedBy { it.label.lowercase() }
    }

    private fun pickApp(index: Int) {
        val entries = ArrayList<AppEntry>()
        if (slotPackage(index).isNotEmpty()) {
            entries.add(AppEntry("Remove from this tile", "", null))
        }
        entries.addAll(installedApps())

        val adapter = object : ArrayAdapter<AppEntry>(this, 0, entries) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val item = getItem(position)!!
                val line = LinearLayout(context).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(16), dp(10), dp(16), dp(10))
                }
                val icon = ImageView(context).apply { setImageDrawable(item.icon) }
                line.addView(icon, LinearLayout.LayoutParams(dp(48), dp(48)))
                val label = TextView(context).apply {
                    text = item.label
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
                    setPadding(dp(16), 0, 0, 0)
                }
                line.addView(label)
                return line
            }
        }

        AlertDialog.Builder(this)
            .setTitle("Choose app for this tile")
            .setAdapter(adapter) { _, which ->
                val chosen = entries[which]
                prefs.edit().putString("slot_$index", chosen.pkg).apply()
                refresh(index)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
