package com.cleanlauncher.tv

import android.app.Activity
import android.app.Dialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.media.tv.TvContract
import android.media.tv.TvInputManager
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

/** Soft dark gradient with two coloured glows, drawn once per frame (no images, no network). */
private class BackgroundView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        paint.shader = LinearGradient(
            0f, 0f, w, h, 0xFF070B18.toInt(), 0xFF121A35.toInt(), Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, w, h, paint)
        paint.shader = RadialGradient(
            w * 0.88f, h * 0.02f, w * 0.6f, 0x663D5AFE, 0x003D5AFE, Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, w, h, paint)
        paint.shader = RadialGradient(
            w * 0.04f, h * 0.98f, w * 0.55f, 0x557C4DFF, 0x007C4DFF, Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, w, h, paint)
    }
}

/**
 * A clean, ad-free TV home screen.
 *  - Big clock and date
 *  - 5 app tiles that always fit the screen (uses the app's own TV banner when it has one)
 *  - OK on a tile opens the app; hold OK (or press MENU) to change it
 *  - "All apps" button opens every installed app
 *  - No internet permission, no tracking, no recommendations
 */
class MainActivity : Activity() {

    private val slotCount = 5

    // First installed package in each list is used until you pick your own app.
    private val defaultCandidates: List<List<String>> = listOf(
        listOf("com.google.android.youtube.tv"),
        listOf("in.startv.hotstar", "in.startv.hotstar.dplus", "com.jio.jiohotstar"),
        listOf("com.netflix.ninja"),
        listOf("com.amazon.amazonvideo.livingroom"),
        listOf()
    )

    private lateinit var prefs: SharedPreferences
    private lateinit var row: LinearLayout
    private var tileW = 0
    private var tileH = 0
    private var tileGap = 0

    private data class AppEntry(val label: String, val pkg: String, val icon: Drawable?)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("slots", MODE_PRIVATE)
        setContentView(buildUi())
    }

    override fun onResume() {
        super.onResume()
        val f = currentFocus
        val idx = if (f != null) row.indexOfChild(f) else 0
        refresh(if (idx < 0) 0 else idx)
    }

    // The Home screen should never "go back" to anything.
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // intentionally empty
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_MENU) {
            val f = currentFocus
            val index = if (f != null) row.indexOfChild(f) else -1
            if (index >= 0) {
                pickApp(index)
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    // ---------------------------------------------------------------- helpers

    private fun dp(v: Int): Int =
        TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics
        ).toInt()

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun pillBg(focused: Boolean): GradientDrawable {
        val d = GradientDrawable()
        d.cornerRadius = dp(26).toFloat()
        d.setColor(if (focused) 0x55FFFFFF else 0x26FFFFFF)
        if (focused) d.setStroke(dp(2), Color.WHITE)
        return d
    }

    private fun makePill(label: String, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = label
        t.setTextColor(Color.WHITE)
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(26), dp(12), dp(26), dp(12))
        t.isFocusable = true
        t.isClickable = true
        t.background = pillBg(false)
        t.setOnFocusChangeListener { v, has -> v.background = pillBg(has) }
        t.setOnClickListener { onClick() }
        return t
    }

    // ---------------------------------------------------------------- main screen

    private fun buildUi(): View {
        val root = FrameLayout(this)
        root.addView(BackgroundView(this), FrameLayout.LayoutParams(MATCH, MATCH))

        val sidePad = dp(56)
        val innerPad = dp(16)
        tileGap = dp(20)
        val avail = resources.displayMetrics.widthPixels - 2 * sidePad - 2 * innerPad
        tileW = (avail - tileGap * (slotCount - 1)) / slotCount
        tileH = (tileW * 0.62f).toInt()

        val content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(sidePad, dp(36), sidePad, dp(28))
        content.clipChildren = false
        content.clipToPadding = false

        // ----- top bar: clock + date on the left, buttons on the right
        val topBar = LinearLayout(this)
        topBar.orientation = LinearLayout.HORIZONTAL
        topBar.gravity = Gravity.CENTER_VERTICAL

        val timeCol = LinearLayout(this)
        timeCol.orientation = LinearLayout.VERTICAL

        val clock = TextClock(this)
        clock.format12Hour = "h:mm a"
        clock.format24Hour = "HH:mm"
        clock.setTextColor(Color.WHITE)
        clock.setTextSize(TypedValue.COMPLEX_UNIT_SP, 56f)
        clock.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        timeCol.addView(clock)

        val date = TextClock(this)
        date.format12Hour = "EEEE, d MMMM"
        date.format24Hour = "EEEE, d MMMM"
        date.setTextColor(0xB3FFFFFF.toInt())
        date.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
        timeCol.addView(date)

        topBar.addView(timeCol, LinearLayout.LayoutParams(0, WRAP, 1f))

        val allApps = makePill("All apps") {
            showAppGrid("All apps", false) { pkg -> launchPackage(pkg) }
        }
        val settings = makePill("Settings") { openSettings() }
        val inputs = makePill("Inputs") { showInputPicker() }

        val lp0 = LinearLayout.LayoutParams(WRAP, WRAP)
        lp0.marginStart = dp(14)
        topBar.addView(inputs, lp0)
        val lp1 = LinearLayout.LayoutParams(WRAP, WRAP)
        lp1.marginStart = dp(14)
        topBar.addView(allApps, lp1)
        val lp2 = LinearLayout.LayoutParams(WRAP, WRAP)
        lp2.marginStart = dp(14)
        topBar.addView(settings, lp2)

        content.addView(topBar, LinearLayout.LayoutParams(MATCH, WRAP))
        content.addView(View(this), LinearLayout.LayoutParams(MATCH, 0, 1f))

        // ----- section title
        val section = TextView(this)
        section.text = "MY APPS"
        section.setTextColor(0x99FFFFFF.toInt())
        section.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        section.letterSpacing = 0.15f
        section.typeface = Typeface.DEFAULT_BOLD
        section.setPadding(innerPad, 0, 0, dp(10))
        content.addView(section, LinearLayout.LayoutParams(WRAP, WRAP))

        // ----- tile row
        val scroll = HorizontalScrollView(this)
        scroll.isHorizontalScrollBarEnabled = false
        scroll.clipChildren = false
        scroll.clipToPadding = false

        row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.clipChildren = false
        row.setPadding(innerPad, dp(14), innerPad, dp(14))
        scroll.addView(row, FrameLayout.LayoutParams(WRAP, WRAP))
        content.addView(scroll, LinearLayout.LayoutParams(MATCH, WRAP))

        content.addView(View(this), LinearLayout.LayoutParams(MATCH, 0, 1.3f))

        // ----- hint
        val hint = TextView(this)
        hint.text = "Hold OK on a tile to change its app"
        hint.setTextColor(0x80FFFFFF.toInt())
        hint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        hint.gravity = Gravity.CENTER
        content.addView(hint, LinearLayout.LayoutParams(MATCH, WRAP))

        root.addView(content, FrameLayout.LayoutParams(MATCH, MATCH))
        return root
    }

    private fun refresh(focusIndex: Int) {
        row.removeAllViews()
        for (i in 0 until slotCount) row.addView(makeTile(i))
        row.getChildAt(focusIndex.coerceIn(0, slotCount - 1))?.requestFocus()
    }

    private fun makeTile(index: Int): View {
        val pkg = slotPackage(index)
        val launchIntent = if (pkg.isNotEmpty()) launchIntentFor(pkg) else null
        val pm = packageManager
        val radius = dp(16).toFloat()

        val tile = LinearLayout(this)
        tile.orientation = LinearLayout.VERTICAL
        tile.gravity = Gravity.CENTER_HORIZONTAL
        tile.isFocusable = true
        tile.isClickable = true
        val tileLp = LinearLayout.LayoutParams(tileW, WRAP)
        tileLp.marginEnd = if (index < slotCount - 1) tileGap else 0
        tile.layoutParams = tileLp

        // card (rounded, clips its content)
        val card = FrameLayout(this)
        card.layoutParams = LinearLayout.LayoutParams(tileW, tileH)
        card.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, radius)
            }
        }
        card.clipToOutline = true

        val appLabel: String
        if (launchIntent != null) {
            val icon = runCatching { pm.getApplicationIcon(pkg) }.getOrNull()
            val banner = runCatching { pm.getActivityBanner(launchIntent) }.getOrNull()
                ?: runCatching { pm.getApplicationBanner(pkg) }.getOrNull()
            val colors = tileColors(dominantColor(runCatching { pm.getApplicationIcon(pkg) }.getOrNull()))
            card.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, colors)

            if (banner != null) {
                val iv = ImageView(this)
                iv.setImageDrawable(banner)
                iv.scaleType = ImageView.ScaleType.CENTER_CROP
                card.addView(iv, FrameLayout.LayoutParams(MATCH, MATCH))
            } else {
                val size = (tileH * 0.5f).toInt()
                val iv = ImageView(this)
                iv.setImageDrawable(icon)
                iv.scaleType = ImageView.ScaleType.FIT_CENTER
                card.addView(iv, FrameLayout.LayoutParams(size, size, Gravity.CENTER))
            }
            appLabel = runCatching {
                pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
            }.getOrDefault(pkg)
        } else {
            val bg = GradientDrawable()
            bg.cornerRadius = radius
            bg.setColor(0x1FFFFFFF)
            bg.setStroke(dp(2), 0x40FFFFFF)
            card.background = bg
            val plus = TextView(this)
            plus.text = "+"
            plus.setTextColor(0xCCFFFFFF.toInt())
            plus.setTextSize(TypedValue.COMPLEX_UNIT_SP, 44f)
            plus.gravity = Gravity.CENTER
            card.addView(plus, FrameLayout.LayoutParams(MATCH, MATCH))
            appLabel = "Add app"
        }

        // white focus ring on top of everything
        val border = View(this)
        val ring = GradientDrawable()
        ring.cornerRadius = radius
        ring.setColor(Color.TRANSPARENT)
        ring.setStroke(dp(3), Color.WHITE)
        border.background = ring
        border.visibility = View.INVISIBLE
        card.addView(border, FrameLayout.LayoutParams(MATCH, MATCH))

        val label = TextView(this)
        label.text = appLabel
        label.setTextColor(Color.WHITE)
        label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        label.gravity = Gravity.CENTER
        label.maxLines = 1
        label.ellipsize = TextUtils.TruncateAt.END
        label.alpha = 0.7f
        label.setPadding(0, dp(10), 0, 0)

        tile.addView(card)
        tile.addView(label, LinearLayout.LayoutParams(MATCH, WRAP))

        tile.setOnFocusChangeListener { v, has ->
            border.visibility = if (has) View.VISIBLE else View.INVISIBLE
            label.alpha = if (has) 1f else 0.7f
            val s = if (has) 1.08f else 1f
            v.animate().scaleX(s).scaleY(s).setDuration(130).start()
        }
        tile.setOnClickListener {
            if (launchIntent != null) launchPackage(pkg) else pickApp(index)
        }
        tile.setOnLongClickListener {
            pickApp(index)
            true
        }
        return tile
    }

    // ---------------------------------------------------------------- colours

    private fun dominantColor(d: Drawable?): Int {
        val fallback = 0xFF3A4A7A.toInt()
        if (d == null) return fallback
        return try {
            val bmp = Bitmap.createBitmap(24, 24, Bitmap.Config.ARGB_8888)
            val c = Canvas(bmp)
            d.setBounds(0, 0, 24, 24)
            d.draw(c)
            var r = 0L
            var g = 0L
            var b = 0L
            var n = 0L
            for (x in 0 until 24) {
                for (y in 0 until 24) {
                    val p = bmp.getPixel(x, y)
                    if (Color.alpha(p) > 200) {
                        r += Color.red(p)
                        g += Color.green(p)
                        b += Color.blue(p)
                        n++
                    }
                }
            }
            bmp.recycle()
            if (n == 0L) fallback else Color.rgb((r / n).toInt(), (g / n).toInt(), (b / n).toInt())
        } catch (e: Exception) {
            fallback
        }
    }

    /** Returns [lighter, darker] versions of the colour, tuned to look good behind white text. */
    private fun tileColors(c: Int): IntArray {
        val hsv = FloatArray(3)
        Color.colorToHSV(c, hsv)
        hsv[1] = hsv[1].coerceAtMost(0.85f)
        val v = hsv[2].coerceIn(0.4f, 0.8f)
        hsv[2] = v
        val dark = Color.HSVToColor(hsv)
        hsv[2] = (v + 0.15f).coerceAtMost(1f)
        val light = Color.HSVToColor(hsv)
        return intArrayOf(light, dark)
    }

    // ---------------------------------------------------------------- data

    private fun slotPackage(index: Int): String {
        val key = "slot_$index"
        if (prefs.contains(key)) return prefs.getString(key, "") ?: ""
        val candidates = defaultCandidates.getOrNull(index).orEmpty()
        return candidates.firstOrNull { launchIntentFor(it) != null } ?: ""
    }

    private fun launchIntentFor(pkg: String): Intent? =
        packageManager.getLeanbackLaunchIntentForPackage(pkg)
            ?: packageManager.getLaunchIntentForPackage(pkg)

    private fun launchPackage(pkg: String) {
        val i = launchIntentFor(pkg)
        if (i == null) {
            toast("App not found")
            return
        }
        try {
            startActivity(i)
        } catch (e: Exception) {
            toast("Could not open this app")
        }
    }

    private fun openSettings() {
        try {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        } catch (e: ActivityNotFoundException) {
            toast("Settings not available")
        }
    }

    // ---------------------------------------------------------------- TV inputs (HDMI, AV...)

    private fun switchInput(inputId: String) {
        try {
            val uri = TvContract.buildChannelUriForPassthroughInput(inputId)
            val i = Intent(Intent.ACTION_VIEW, uri)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (e: Exception) {
            toast("Could not switch to this input")
        }
    }

    private fun showInputPicker() {
        val manager = getSystemService(Context.TV_INPUT_SERVICE) as? TvInputManager
        val inputs = ArrayList<Pair<String, String>>() // label to input id
        if (manager != null) {
            for (info in manager.tvInputList) {
                if (!info.isPassthroughInput) continue
                if (info.isHidden(this)) continue
                val raw: CharSequence? = info.loadCustomLabel(this) ?: info.loadLabel(this)
                val label = raw?.toString() ?: info.id
                inputs.add(Pair(label, info.id))
            }
        }
        inputs.sortBy { it.first.lowercase() }
        if (inputs.isEmpty()) {
            toast("No inputs found. Use the Source button on your remote.")
            return
        }

        val dialog = Dialog(this, android.R.style.Theme_DeviceDefault_NoActionBar_Fullscreen)

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(56), dp(36), dp(56), dp(24))

        val heading = TextView(this)
        heading.text = "Switch input"
        heading.setTextColor(Color.WHITE)
        heading.setTextSize(TypedValue.COMPLEX_UNIT_SP, 30f)
        heading.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        heading.setPadding(0, 0, 0, dp(20))
        box.addView(heading, LinearLayout.LayoutParams(MATCH, WRAP))

        val selector = GradientDrawable()
        selector.cornerRadius = dp(14).toFloat()
        selector.setColor(0x33FFFFFF)
        selector.setStroke(dp(3), Color.WHITE)

        val grid = GridView(this)
        grid.numColumns = 3
        grid.verticalSpacing = dp(16)
        grid.horizontalSpacing = dp(16)
        grid.stretchMode = GridView.STRETCH_COLUMN_WIDTH
        grid.setSelector(selector)

        val ctx = this
        grid.adapter = object : BaseAdapter() {
            override fun getCount(): Int = inputs.size
            override fun getItem(position: Int): Any = inputs[position]
            override fun getItemId(position: Int): Long = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val t = TextView(ctx)
                t.text = inputs[position].first
                t.setTextColor(Color.WHITE)
                t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
                t.gravity = Gravity.CENTER
                t.setPadding(dp(16), dp(30), dp(16), dp(30))
                val bg = GradientDrawable()
                bg.cornerRadius = dp(14).toFloat()
                bg.setColor(0x26FFFFFF)
                t.background = bg
                return t
            }
        }
        grid.setOnItemClickListener { _, _, position, _ ->
            dialog.dismiss()
            switchInput(inputs[position].second)
        }

        box.addView(grid, LinearLayout.LayoutParams(MATCH, 0, 1f))
        dialog.setContentView(box)
        dialog.window?.setBackgroundDrawable(ColorDrawable(0xF2101528.toInt()))
        dialog.show()
        grid.requestFocus()
    }

    private fun installedApps(): List<AppEntry> {
        val pm = packageManager
        val tv = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
        val phone = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return (pm.queryIntentActivities(tv, 0) + pm.queryIntentActivities(phone, 0))
            .map { it.activityInfo.packageName to it }
            .distinctBy { it.first }
            .filter { it.first != packageName }
            .map { (pkg, info) ->
                AppEntry(
                    info.loadLabel(pm).toString(),
                    pkg,
                    runCatching { info.loadIcon(pm) }.getOrNull()
                )
            }
            .sortedBy { it.label.lowercase() }
    }

    // ---------------------------------------------------------------- app grid dialog

    private fun pickApp(index: Int) {
        val hasApp = slotPackage(index).isNotEmpty()
        showAppGrid("Choose an app for this tile", hasApp) { pkg ->
            prefs.edit().putString("slot_$index", pkg).apply()
            refresh(index)
        }
    }

    private fun showAppGrid(title: String, withRemove: Boolean, onPick: (String) -> Unit) {
        val apps = ArrayList<AppEntry>()
        if (withRemove) apps.add(AppEntry("Remove", "", null))
        apps.addAll(installedApps())

        val dialog = Dialog(this, android.R.style.Theme_DeviceDefault_NoActionBar_Fullscreen)

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(56), dp(36), dp(56), dp(24))

        val heading = TextView(this)
        heading.text = title
        heading.setTextColor(Color.WHITE)
        heading.setTextSize(TypedValue.COMPLEX_UNIT_SP, 30f)
        heading.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        heading.setPadding(0, 0, 0, dp(20))
        box.addView(heading, LinearLayout.LayoutParams(MATCH, WRAP))

        val selector = GradientDrawable()
        selector.cornerRadius = dp(14).toFloat()
        selector.setColor(0x33FFFFFF)
        selector.setStroke(dp(2), Color.WHITE)

        val grid = GridView(this)
        grid.numColumns = 6
        grid.verticalSpacing = dp(14)
        grid.horizontalSpacing = dp(14)
        grid.stretchMode = GridView.STRETCH_COLUMN_WIDTH
        grid.setSelector(selector)
        grid.clipToPadding = false

        val ctx = this
        grid.adapter = object : BaseAdapter() {
            override fun getCount(): Int = apps.size
            override fun getItem(position: Int): Any = apps[position]
            override fun getItemId(position: Int): Long = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val item = apps[position]
                val cell = LinearLayout(ctx)
                cell.orientation = LinearLayout.VERTICAL
                cell.gravity = Gravity.CENTER
                cell.setPadding(dp(8), dp(14), dp(8), dp(10))

                if (item.icon != null) {
                    val iv = ImageView(ctx)
                    iv.setImageDrawable(item.icon)
                    cell.addView(iv, LinearLayout.LayoutParams(dp(64), dp(64)))
                } else {
                    val x = TextView(ctx)
                    x.text = "×"
                    x.setTextColor(Color.WHITE)
                    x.setTextSize(TypedValue.COMPLEX_UNIT_SP, 40f)
                    x.gravity = Gravity.CENTER
                    cell.addView(x, LinearLayout.LayoutParams(dp(64), dp(64)))
                }

                val name = TextView(ctx)
                name.text = item.label
                name.setTextColor(Color.WHITE)
                name.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                name.gravity = Gravity.CENTER
                name.maxLines = 1
                name.ellipsize = TextUtils.TruncateAt.END
                name.setPadding(0, dp(8), 0, 0)
                cell.addView(name, LinearLayout.LayoutParams(MATCH, WRAP))
                return cell
            }
        }
        grid.setOnItemClickListener { _, _, position, _ ->
            dialog.dismiss()
            onPick(apps[position].pkg)
        }

        box.addView(grid, LinearLayout.LayoutParams(MATCH, 0, 1f))
        dialog.setContentView(box)
        dialog.window?.setBackgroundDrawable(ColorDrawable(0xF2101528.toInt()))
        dialog.show()
        grid.requestFocus()
    }
}
