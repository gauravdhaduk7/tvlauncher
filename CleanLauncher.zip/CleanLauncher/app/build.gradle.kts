plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.cleanlauncher.tv"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.cleanlauncher.tv"
        minSdk = 21
        targetSdk = 33
        versionCode = 3
        versionName = "2.1"
    }

    // A fixed signing key kept in the project, so every future build can be installed
    // over the previous one (without this, each online build gets a new random key).
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

// No third-party libraries on purpose: no ads, no trackers, no network code.
